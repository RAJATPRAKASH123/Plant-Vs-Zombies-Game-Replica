package sample;

public class Plant {
    int health;
    int x;
    int y;
}
