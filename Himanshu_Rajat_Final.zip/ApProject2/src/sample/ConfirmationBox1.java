package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;



import java.io.IOException;


public class ConfirmationBox1 {
    Stage curstage = Main.stage;
    boolean answer;


    public boolean display(String title, String message){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(300);
        window.setMaxHeight(300);

        Label label = new Label();
        label.setText(message);

        Button Main_Menu = new Button("Next Level ");
        Button save = new Button("Save");
        System.out.println("hhhh");


        Main_Menu.setOnAction(e -> {

            Parent view2 = null;
            try {
                view2 = FXMLLoader.load(getClass().getResource("Level2.fxml"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            Scene scene2 = new Scene(view2,610,345);

            this.curstage = (Stage) ((Node)e.getSource()).getScene().getWindow();
            this.curstage.setScene(scene2);
            this.curstage.show();
            answer = true;

        });

        save.setOnAction(e ->{
            answer = false;
        });

        VBox layout = new VBox(10);
        layout.getChildren().addAll(Main_Menu,label);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
        return answer;









    }
}
