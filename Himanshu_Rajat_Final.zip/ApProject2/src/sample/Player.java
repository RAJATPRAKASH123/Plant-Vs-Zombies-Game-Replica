package sample;

import java.io.Serializable;
import java.util.ArrayList;

public class Player implements Serializable {
    String name;
    int Level = 0;
    int sun_token;
    ArrayList<Plant> plant_List ;
    ArrayList<Zombie> Zombie_List;
    ArrayList<LawnMover> Lawnmover_Detail ;
    public Player( String name, int Level )
    {
        this.name = name;
        this.Level = Level;
    }


}
