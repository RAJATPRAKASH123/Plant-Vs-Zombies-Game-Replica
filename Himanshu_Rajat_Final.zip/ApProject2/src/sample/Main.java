package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;


public class Main extends Application {


    public static Stage stage;
    Media sound;
    MediaPlayer mediaPlayer;
    public static Player p = new Player("Himanshu Yadav", 5);
    public static ArrayList<Player> players_details = new ArrayList<Player>();





    LawnController l = new LawnController();
    public static void serialize(ArrayList<Player> P) throws IOException {
        ObjectOutputStream out=null;
        try{
            out= new ObjectOutputStream(new FileOutputStream("save.txt"));
            out.writeObject(P);
        }
        finally {
            out.close();
        }

    }

    public static ArrayList<Player> deserialize() throws IOException,ClassNotFoundException {
        ObjectInputStream in = null;
        ArrayList<Player> P;
        try {
            in = new ObjectInputStream(new FileInputStream("save.txt"));
            P = (ArrayList<Player>) in.readObject();
        }
        finally {
            if ( in != null )
            {
                in.close();
            }

        }
        return P;
    }

    static ArrayList<Zombie> create_Random_Zombies(int n )
    {
        ArrayList<Zombie> all_zombies = new ArrayList<Zombie>();
        Random rand = new Random();


        for ( int i = 0; i < n ; i++ )
        {
            int rand_health = rand.nextInt(10);
            int rand_x = rand.nextInt(100) + 400;

            int rand_y = rand.nextInt(1000) ;

            all_zombies.add(new Zombie(rand_health, rand_x, rand_y));
        }
        return all_zombies;
    }

    @Override
    public void start(Stage primaryStage) throws Exception{



//        try {
//            sound = new Media(new File("C:/Users/Himanshu/Desktop/ApProject2/src/OnMyWay.mp3").toURI().toString());
//            mediaPlayer = new MediaPlayer(sound);
//            mediaPlayer.play();
//        } catch (Exception e){
//            System.out.println(e.getMessage());
//        }
        players_details.add(new Player("Himanshu",1));
        players_details.add(new Player("Himanshu2",2));
        players_details.add(new Player("Himanshu3",3));
        players_details.add(new Player("Himanshu4",4));
        players_details.add(new Player("Himanshu4",5));
        players_details.add(new Player("Rajat",2));
        players_details.add(new Player("Yadav",3));
        players_details.add(new Player("Shubhangi",4));
        Pane root = FXMLLoader.load(getClass().getResource("Registration.fxml"));
        primaryStage.setTitle("Hello World");
         Scene scene = new Scene(root, 610, 345);
        primaryStage.setScene(scene);
        //String path = "C:\\Users\\Himanshu\\Desktop\\ApProject2\\src\\On My Way.mp3";

        //Instantiating Media class
        //Media media = new Media(new File(path).toURI().toString());

        //Instantiating MediaPlayer class
        //MediaPlayer mediaPlayer = new MediaPlayer(media);

        //by setting this property to true, the audio will be played
        //mediaPlayer.setAutoPlay(true);

        primaryStage.show();

    }


    public static void main(String[] args) {
        launch(args);
    }
}
