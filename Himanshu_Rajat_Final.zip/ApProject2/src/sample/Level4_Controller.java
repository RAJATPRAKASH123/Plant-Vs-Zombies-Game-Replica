package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

public class Level4_Controller  implements Initializable {
    @FXML
    private AnchorPane pane;

    @FXML
    private ImageView zombie_image1;

    @FXML
    private ImageView zombie_image11;

    @FXML
    private ImageView zombie_image111;

    @FXML
    private ImageView mover1;

    ImageView sunFLower;
    ImageView sun;
    ImageView pea_imageView;
    ImageView img;
    boolean done_once = false;
    int health = 3;
    boolean band = false;
    @FXML
    private Label mymsg;
    @FXML
    private Button sun1;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //startTimer(1);
        int ccc = 0; int xx = 3;
        TranslateTransition transition = new TranslateTransition();
        transition.setDuration(Duration.seconds(8));
        transition.setNode(sun1);
        transition.setCycleCount(500);

        transition.setToX(+500);
        transition.setToY(ccc+=200 * xx);
        transition.play();
        //startTimer(1);
    }

    Timeline animation;
    int count = 100;
    String s = "";

    Stage curstage = Main.stage;

    @FXML
    private void GotoLevel1(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("sample.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);

        this.curstage.show();



    }
    @FXML
    private void Sun_disappear (ActionEvent event) throws IOException, InterruptedException {
        animation = new Timeline(new KeyFrame(Duration.seconds(1)));
        sun1.setVisible(true);
        System.out.println("papa");
        if(count >= 0){
            count+=50;
        }
        s = count + "";
        mymsg.setText(s);
        animation.setCycleCount(Timeline.INDEFINITE);
        Timeline timeline6 = new Timeline();
        for ( int i = 0; i <= 4; i++ )
        {
            final int timeRem = 1 - i;
            KeyFrame frame = new KeyFrame(Duration.seconds(i),
                    e-> sun1.setVisible(false));
            timeline6.getKeyFrames().add(frame);
        }
        for ( int i = 4; i <= 5; i++ )
        {
            final int timeRem = 3 - i;
            KeyFrame frame = new KeyFrame(Duration.seconds(i),
                    e-> sun1.setVisible(true));
            timeline6.getKeyFrames().add(frame);
        }
        sun1.setVisible(true);
        timeline6.play();
        //startTimer(2);
        //TimeUnit.SECONDS.sleep(4);


        //sun1.setDisable(true);
//        sun1.setVisible(false);
//        TimeUnit.SECONDS.sleep(1);
//        sun1.setDisable(false);
//        sun1.setVisible(true);
    }

    @FXML
    private void Sun_count (ActionEvent event)throws IOException {
        int him;
    }

    @FXML
    void Sun_Flower(MouseEvent event) throws FileNotFoundException {
        FileInputStream input = new FileInputStream("./src/xxxxxxxxxxxx.png");
        Image pea_image = new Image(input);
        sunFLower = new ImageView(pea_image);
        sunFLower.setX(event.getX());
        sunFLower.setY(event.getY());
        sunFLower.setFitHeight(71);
        sunFLower.setFitWidth(70);


        FileInputStream input1 = new FileInputStream("./src/sun.png");
        Image image1 = new Image(input1);
        //ImageButton sun = new ImageButton();
        sun = new ImageView(image1);
        sun.setX(sunFLower.getX()+20);
        sun.setY(sunFLower.getY()+2);

        pane.getChildren().addAll(sunFLower,sun);
    }



    @FXML
    void Pea_Shooter(MouseEvent event) throws FileNotFoundException {
        FileInputStream input = new FileInputStream("./src/plantShooter.gif");
        Image pea_image = new Image(input);
        pea_imageView = new ImageView(pea_image);
        pea_imageView.setX(event.getX());
        pea_imageView.setY(event.getY());
        pea_imageView.setFitHeight(71);
        pea_imageView.setFitWidth(70);
        FileInputStream input1 = new FileInputStream("./src/pea.png");
        Image image1 = new Image(input1);
        img = new ImageView(image1);
        img.setX(pea_imageView.getX()+7);
        img.setY(pea_imageView.getY()-3);

        pane.getChildren().addAll(pea_imageView,img);
        startTimer(2);
    }

    Timer timer = new Timer();

    public void startTimer(int x) {

        TimerTask timerTask = new TimerTask() {
            public void run() {
                Platform.runLater(new Runnable() {
                    public void run() {
                        if(x==1){
                            updateAnimation_Zombie();
                        }
                        else{
                            updateAnimation();
                            updateAnimation2();
                            updateAnimation3();
                        }
                        collide();
                        Collide2();
                        if(band==true){
                            timer.cancel();
                        }
                    }
                });
            }
        };
        long frameTimeInMilliseconds = (long) (1);
        this.timer.schedule(timerTask, 0, frameTimeInMilliseconds);
    }

    public Double updateAnimation2(){
        double s1 = 0;

        if(sunFLower != null) {
            s1 = sunFLower.getX();
        }
        s1 = s1+0;

        if(sunFLower != null)
            sunFLower.setX(s1);
        //System.out.println(s1 + "xxxxxxxxx");
        return s1;
    }
    double timegap = 0;
    public Double updateAnimation3(){
        timegap = timegap + 0.1;
        //System.out.println(timegap);
        return timegap;
    }


    public Double updateAnimation_Zombie(){
        double s2 = 0;
        double s3 = 0;
        if(zombie_image1 != null){
            s2 = zombie_image1.getX();
            s3 = zombie_image11.getX();
        }
        s2 = s2-0.01f;
        s3 = s3-0.01f;
        if(zombie_image1 != null)
            zombie_image1.setX(s2);
        zombie_image11.setX(s3);
        //System.out.println(s2);
        return s2;
    }
    double pea = 0;
    double zombie = 0;


    public void Collide2(){
        pea = updateAnimation2();
        //System.out.println(pea);
        zombie = updateAnimation_Zombie();
        //System.out.println(-(int)zombie);
        if((-zombie >= 650-pea)){
            //System.out.println("xxxxxxxx");
            zombie_image1.setVisible(false);
            zombie_image11.setVisible(false);
            sunFLower.setVisible(false);
        }


    }

    public void collide(){
        pea = updateAnimation();
        zombie = updateAnimation_Zombie();
        //System.out.println(zombie);
        //System.out.println(pea);
        //Math.abs(((-1*zombie)+50) + pea  - 600) < 0.1

        if( -zombie >= 550-pea && done_once==false && pea_imageView.getY()< 105) {
            System.out.println("done"); //&& -zombie<=400+pea
            done_once = true;
            img.setVisible(false);
            health--;
            if (health == 0) {
                System.out.println("zombie dead");
                zombie_image1.setVisible(false);
                band = true;
                //ConfirmationBox1 c1= new ConfirmationBox1();
                //boolean result = c1.display("ss","sx");
            }
        }
        if( -zombie >= 550-pea && done_once==false && pea_imageView.getY()> 105) {
            System.out.println("done"); //&& -zombie<=400+pea
            done_once = true;
            img.setVisible(false);
            health--;
            if (health == 0) {
                System.out.println("zombie dead");
                zombie_image11.setVisible(false);
                band = true;
                //ConfirmationBox1 c1= new ConfirmationBox1();
                //boolean result = c1.display("ss","sx");
            }
        }
    }

    public Double updateAnimation(){
        double s1 = 0;

        if(img != null) {
            s1 = img.getX();
            //System.out.println(img.getY());
        }
        s1 = s1+0.10f;

        if(s1>651 && pea_imageView != null){
            done_once=false;
            img.setVisible(true);
            s1 = pea_imageView.getX() ;


        }
        if(img != null)
            img.setX(s1);
        //System.out.println(s1 + "xxxxxxxxx");
        return s1;
    }

}

