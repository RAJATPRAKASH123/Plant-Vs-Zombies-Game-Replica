package sample;

import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
        import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Reg_Controller {

    Stage stage;
    private Stage curstage = Main.stage;
    @FXML
    private TextField text12;

    @FXML
    private void Goto(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Signup.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }
    static String  name;

    @FXML
    private void GotoLawn(ActionEvent event) throws IOException, ClassNotFoundException {
        name = text12.getText();
        Player p = Main.p;
        p.name = name;
        ArrayList<Player> pxx = Main.players_details;
        pxx.add(p);
        ArrayList<Player> temp = new ArrayList<Player>();
        temp = Main.deserialize();
        if ( temp != null )
        {
            temp.add(p);
        }
        Main.serialize(pxx);
//        ArrayList<Player> xx = new ArrayList<Player>() ;
//
//        xx = Main.deserialize();
//        System.out.println(xx.get(0).name);
//        //System.out.println("xxx   " + s);

        Parent view2 = FXMLLoader.load(getClass().getResource("sample.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        this.curstage.show();
        //System.out.println(tf.getText());

    }





}

class Flyweighted {

    private static Player player = new Player("Himanshu",4);

    private static Map<Integer, Flyweighted> instances
            = new HashMap<Integer, Flyweighted>();
    private Flyweighted(int key) {  }
    public static Flyweighted getInstance(int key) {
        if (player.Level == key) {
            instances.put(key, new Flyweighted(key));
        }
        return instances.get(key);
    }
}