package sample;

import javafx.scene.control.Button;

public class Zombie {

    int health;
    int x;
    int y;
    Button button;

    public Button getButton() {
        return button;
    }

    public void setButton(Button button) {
        this.button = button;
    }

    public Zombie(int health, int x, int y)
    {
        this.health = health;
        this.x = x;
        this.y = y;

    }

}
