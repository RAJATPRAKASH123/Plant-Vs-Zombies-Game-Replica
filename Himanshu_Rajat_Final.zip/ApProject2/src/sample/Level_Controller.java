package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Level_Controller implements Initializable {


    Stage curstage = Main.stage;

    @FXML
    private Button level1;

    @FXML
    private Button level2;

    @FXML
    private Button level3;

    @FXML
    private Button level4;

    @FXML
    private Button level5;

    ArrayList<String> player_Name ;




    @FXML
    private void Gotofirstpage(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("sample.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }


    @FXML
    private void GotoLevel1(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Lawn.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);

        this.curstage.show();



    }
    @FXML
    private void GotoLevel2(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level2.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }

    @FXML
    private void GotoLevel3(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level3.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }

    @FXML
    private void GotoLevel4(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level4.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }
    @FXML
    private void GotoLevel5(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level5.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }
    @FXML
    private void GotoFree(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Free_Play.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        //this.curstage.setResizable(false);
        this.curstage.show();

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ArrayList<String > xxx = new ArrayList<String>();
        System.out.println(Reg_Controller.name);
        xxx.add(Reg_Controller.name);
        for ( int i = 0; i < xxx.size(); i++ )
        {
            System.out.println("dzzz");
            System.out.println(xxx);

            if(xxx.get(i).equals("Himanshu4")) {
                level5.setDisable(true);
            }
            if(xxx.get(i).equals("Himanshu3")) {
                System.out.println("dddd");
                level4.setDisable(true);
                level5.setDisable(true);
            }
            if(xxx.get(i).equals("Himanshu2")) {
                level4.setDisable(true);
                level5.setDisable(true);
                level3.setDisable(true);
            }
            if(xxx.get(i).equals("Himanshu1")) {
                level5.setDisable(true);
                level2.setDisable(true);
                level3.setDisable(true);
                level4.setDisable(true);
            }
            if(xxx.get(i) == "Himanshu5") {
                //level3.setDisable(true);level1.setDisable(true);
            }


        }

        }


}