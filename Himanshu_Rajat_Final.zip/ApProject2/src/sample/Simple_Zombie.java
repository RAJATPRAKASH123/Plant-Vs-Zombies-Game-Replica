package sample;

public class Simple_Zombie {
}
