package sample;

public class LawnMover {
    int row_no;
    int speed;
}
