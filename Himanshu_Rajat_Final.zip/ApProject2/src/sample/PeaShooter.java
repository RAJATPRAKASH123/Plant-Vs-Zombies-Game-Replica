package sample;

public class PeaShooter extends Plant {

}
