package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller  implements Initializable {
    @FXML
    public Button closeButton;
    //Stage stage = new Stage();
    Stage curstage = Main.stage;


    @FXML
    private void addScene(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level.fxml"));

        Scene scene2 = new Scene(view2,610,345);
        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        this.curstage.show();
    }

    @FXML
    public void handleCloseButtonAction(ActionEvent event) {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void For_Load_Page(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level.fxml"));

        Scene scene2 = new Scene(view2,610,345);
        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        this.curstage.show();
    }

    @FXML
    private void GoToLevel(ActionEvent event)throws IOException {
        Parent view2 = FXMLLoader.load(getClass().getResource("Level.fxml"));

        Scene scene2 = new Scene(view2,610,345);

        //Stage stage = new Stage();
        this.curstage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        this.curstage.setScene(scene2);
        this.curstage.show();

    }

//    String path = "C:\\Users\\Himanshu\\Desktop\\ApProject2\\src\\On My Way.mp3";
//
//
//    Media media = new Media(new File(path).toURI().toString());
//
//
//    MediaPlayer mediaPlayer = new MediaPlayer(media);
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //mediaPlayer.play();
    }
}
