package sample;

public class Sun {
    int spped;
    int sun_price;
}
